//! MYSTIC - Exact Chaos Mathematics
//!
//! Mathematically Yielding Stable Trajectory Integer Computation
//!
//! Zero-drift chaos simulation using exact integer arithmetic.
//! Eliminates the butterfly effect by removing floating-point error accumulation.
//!
//! Named in memory of Camp Mystic. No more flash flood tragedies.
//!
//! # Core Principle
//!
//! Traditional chaos: Error × e^(λt) → ∞ as t → ∞
//! MYSTIC chaos: 0 × e^(λt) = 0 (no initial error to amplify)
//!
//! # Applications
//!
//! - Weather prediction without drift
//! - Flash flood attractor detection
//! - Long-term climate modeling
//! - Any chaotic system requiring exact trajectories

pub mod lorenz;
pub mod lyapunov;
pub mod attractor;
pub mod weather;

// Re-export all public types for convenient access
pub use lorenz::{ExactLorenz, LorenzState, LorenzParams};
pub use lyapunov::{LyapunovAnalyzer, LyapunovExponent, ChaosSignature};
pub use attractor::{AttractorDetector, AttractorSignature, AttractorBasin, AttractorId};
pub use weather::{WeatherState, FloodDetector, DelugeEngine, AlertLevel, FloodPrediction, RawSensorData};
